#!/usr/bin/env python3
"""
Test script for the new concurrent processing system.
"""

import sys
import os
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
load_dotenv()

# Set the ZenRows API key
os.environ['ZENROWS_API_KEY'] = os.getenv('ZENROWS_API_KEY')

from main import get_socket_data, normalize_item, enrich_item
from scraper_concurrent import process_advisories_concurrent, print_queue_status

# Sample advisory data for testing
sample_advisories = [
    {
        "ghsa_id": "GHSA-vgmg-gc55-wr7g",
        "summary": "Malware in paypal-invoicing", 
        "published_at": "2025-07-22T01:50:36Z",
        "vulnerabilities": [{
            "package": {
                "name": "paypal-invoicing",
                "ecosystem": "npm"
            },
            "vulnerable_version_range": ">= 0"
        }]
    },
    {
        "ghsa_id": "GHSA-test-1234",
        "summary": "Test package vulnerability",
        "published_at": "2025-07-22T01:50:36Z", 
        "vulnerabilities": [{
            "package": {
                "name": "react-qrcode-icon",
                "ecosystem": "npm"
            },
            "vulnerable_version_range": ">= 0"
        }]
    }
]

def main():
    print("🧪 Testing Concurrent Processing System")
    print("="*50)
    
    # Print initial queue status
    print("\n📊 Initial queue status:")
    print_queue_status()
    
    # Test concurrent processing with sample data
    print(f"\n🚀 Processing {len(sample_advisories)} sample advisories...")
    
    successful, failed = process_advisories_concurrent(
        sample_advisories,
        get_socket_data_func=get_socket_data,
        normalize_func=normalize_item,
        enrich_func=enrich_item,
        max_workers=2  # Small number for testing
    )
    
    print(f"\n✅ Results:")
    print(f"  - Successful: {successful}")
    print(f"  - Failed: {failed}")
    
    # Print final queue status
    print("\n📊 Final queue status:")
    print_queue_status()
    
    print("\n✅ Test complete!")

if __name__ == "__main__":
    main()