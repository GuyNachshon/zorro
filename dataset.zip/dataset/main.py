from pprint import pprint
import urllib
import requests
from scraper import build_from_scratch, update_advisories
import json
import os
from bs4 import BeautifulSoup
from firecrawl import Firecrawl
from tqdm import tqdm
import threading
import time
import atexit
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# Import concurrent processing system
from scraper_concurrent import (
    process_advisories_concurrent,
    print_queue_status,
    retry_failed_packages,
    PackageQueueManager
)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, 'packages')
ADVISORIES_FILE = os.path.join(SCRIPT_DIR, 'github_advisories.json')

# ZenRows configuration (replace with your actual API key)
ZENROWS_API_KEY = os.getenv('ZENROWS_API_KEY', )
FIRECRAWL_API_KEY = os.getenv('FIRECRAWL_API_KEY')

app = Firecrawl(api_key=FIRECRAWL_API_KEY)  # Keep for backward compatibility

PACKAGE_MANAGER_MAP = {
    'npm': 'npm',
    'pip': 'pypi',
    'rust': 'cargo'
}


def zenrows_request(url, js_render=False, timeout=30):
    """Make a request through ZenRows proxy to bypass anti-bot protection."""
    params = {
        'url': url,
        'apikey': ZENROWS_API_KEY,
    }

    # Add JavaScript rendering if needed
    if js_render:
        params['js_render'] = 'true'

    try:
        response = requests.get(
            'https://api.zenrows.com/v1/',
            params=params,
            timeout=timeout
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        print(f"❌ ZenRows request failed for {url}: {e}")
        raise


def normalize_item(item):
    package_info = item.get("vulnerabilities", [{}])[0].get("package", {})
    return {
        "ghsa_id": item.get("ghsa_id"),
        "summary": item.get("summary"),
        "published": item.get("published_at"),
        "reviewed": item.get("github_reviewed_at"),
        "updated": item.get("updated_at"),
        "source_code_location": item.get("source_code_location", ''),
        "package_name": package_info.get("name"),
        "package_manager": PACKAGE_MANAGER_MAP.get(package_info.get("ecosystem"), package_info.get("ecosystem").lower()),
        "vulnerable_version_range": item.get("vulnerabilities", [{}])[0].get("vulnerable_version_range", ">=0"),
        "vulnerable_functions": item.get("vulnerabilities", [{}])[0].get("vulnerable_functions", []),
        "first_patched_version": item.get("vulnerabilities", [{}])[0].get("first_patched_version"),
    }


def enrich_item(item):
    package_name = item.get("package_name")
    package_manager = item.get("package_manager")
    match package_manager:
        case "npm":
            item["package_url"] = f"https://www.npmjs.com/package/{package_name}"
        case "pypi":
            item["package_url"] = f"https://pypi.org/project/{package_name}"
        case "rubygems":
            item["package_url"] = f"https://rubygems.org/gems/{package_name}"
        case "composer":
            item["package_url"] = f"https://packagist.org/packages/{package_name}"
        case "rust":
            item["package_url"] = f"https://crates.io/crates/{package_name}"
    return item


def build_repo_structure(tree_items):
    structure = {}
    for item in tqdm(tree_items, desc="Building repository structure"):
        _link = item.find('a', recursive=False).get('href')
        _name = item.find('a', recursive=False).text.strip()
        _type = item.get('data-type')
        if _type == 'file':
            file_page = app.scrape(_link, formats=["html"])
            file_soup = BeautifulSoup(file_page.html, 'html.parser')
            file_raw_link = file_soup.find('a', {'data-testid': 'file-explorer/raw-button'}).get('href')
            structure[_name] = {
                'type': 'file',
                'link': _link,
                'raw_link': file_raw_link
            }
        elif _type == 'dir':
            sub_items = app.scrape(_link, formats=["html"])
            sub_soup = BeautifulSoup(sub_items.html, 'html.parser')
            sub_tree = sub_soup.find('ul', {'data-testid': 'file-explorer/file-list'})
            sub_items = sub_tree.find_all('li', recursive=False)
            structure[_name] = {
                'type': 'directory',
                'link': _link,
                'children': build_repo_structure(sub_items)
            }
    return structure


def get_repository_structure(package_manager, package_name, version):
    """Get repository structure for a specific package version using ZenRows."""
    try:
        # Get the version page with file explorer via ZenRows
        version_url = f"https://socket.dev/{package_manager}/package/{package_name}/files/{version}"

        response = zenrows_request(version_url, js_render=True)

        # Parse the HTML to extract repository structure
        soup = BeautifulSoup(response.text, 'html.parser')
        _tree = soup.find('ul', {'data-testid': 'file-explorer/file-list'})

        if _tree:
            tree_items = _tree.find_all('li', recursive=False)
            tree = build_repo_structure_http(tree_items, max_depth=2, max_files_per_dir=10)
            return tree
        else:
            print(f"⚠️ No file explorer found for {package_name} version {version}")
            return None

    except Exception as e:
        print(f"❌ Error fetching repository structure for {package_name}@{version}: {e}")
        return None


def build_repo_structure_http(tree_items, max_depth=3, max_files_per_dir=15, current_depth=0):
    """
    Build repository structure using ZenRows proxy requests with optimization limits.
    
    Args:
        tree_items: HTML elements representing files/directories
        max_depth: Maximum directory depth to traverse
        max_files_per_dir: Maximum files to process per directory
        current_depth: Current traversal depth
    """
    structure = {}

    # Limit files processed per directory for efficiency
    limited_items = tree_items[:max_files_per_dir]
    
    # Check if we've reached maximum depth
    if current_depth >= max_depth:
        # Still get basic info but don't recurse further
        for item in limited_items:
            try:
                link_element = item.find('a', recursive=False)
                if not link_element:
                    continue
                _name = link_element.text.strip()
                _type = item.get('data-type')
                
                if _name:
                    structure[_name] = {
                        'type': _type,
                        'max_depth_reached': True
                    }
            except Exception:
                continue
        return structure

    progress_desc = f"Building structure (depth {current_depth})"
    for item in tqdm(limited_items, desc=progress_desc, leave=False):
        try:
            link_element = item.find('a', recursive=False)
            if not link_element:
                continue

            _link = link_element.get('href')
            _name = link_element.text.strip()
            _type = item.get('data-type')

            if not _link or not _name:
                continue

            if _type == 'file':
                # For files, get the raw content link via ZenRows
                full_url = f"https://socket.dev{_link}" if not _link.startswith('http') else _link

                file_raw_link = None
                max_retries = 2
                
                for attempt in range(max_retries + 1):
                    try:
                        file_response = zenrows_request(full_url, js_render=True)
                        file_soup = BeautifulSoup(file_response.text, 'html.parser')
                        
                        # Try multiple selectors for the raw button
                        raw_button = (
                            file_soup.find('a', {'data-testid': 'file-explorer/raw-button'}) or
                            file_soup.find('a', string='Raw') or
                            file_soup.find('a', {'href': lambda x: x and '/blob/' in x})
                        )
                        
                        if raw_button:
                            file_raw_link = raw_button.get('href')
                            # Ensure we have a blob URL for consistency
                            if file_raw_link and '/blob/' not in file_raw_link:
                                # Try to convert to blob format
                                if '/files/' in file_raw_link:
                                    file_raw_link = file_raw_link.replace('/files/', '/blob/')
                        
                        break  # Success, exit retry loop
                        
                    except Exception as e:
                        if attempt == max_retries:
                            print(f"⚠️ Failed to process file {_name} after {max_retries + 1} attempts: {e}")
                        else:
                            print(f"⚠️ Retry {attempt + 1}/{max_retries} for file {_name}: {e}")
                            time.sleep(1)  # Brief delay before retry

                structure[_name] = {
                    'type': 'file',
                    'link': _link,
                    'raw_link': file_raw_link
                }

            elif _type == 'dir':
                # For directories, recursively get subdirectories via ZenRows
                full_url = f"https://socket.dev{_link}" if not _link.startswith('http') else _link

                children = {}
                max_retries = 2
                
                for attempt in range(max_retries + 1):
                    try:
                        dir_response = zenrows_request(full_url, js_render=False)
                        dir_soup = BeautifulSoup(dir_response.text, 'html.parser')
                        
                        # Try multiple selectors for file list
                        sub_tree = (
                            dir_soup.find('ul', {'data-testid': 'file-explorer/file-list'}) or
                            dir_soup.find('ul', {'class': lambda x: x and 'file-list' in x.lower()}) or
                            dir_soup.find('div', {'data-testid': 'file-explorer'}).find('ul') if dir_soup.find('div', {'data-testid': 'file-explorer'}) else None
                        )

                        if sub_tree:
                            sub_items = sub_tree.find_all('li', recursive=False)
                            if sub_items:  # Only recurse if we found actual items
                                children = build_repo_structure_http(
                                    sub_items, 
                                    max_depth=max_depth, 
                                    max_files_per_dir=max_files_per_dir,
                                    current_depth=current_depth + 1
                                )
                                break  # Success, exit retry loop
                        
                        if attempt == max_retries:
                            print(f"⚠️ No file list found for directory {_name} after {max_retries + 1} attempts")
                        
                    except Exception as e:
                        if attempt == max_retries:
                            print(f"⚠️ Failed to process directory {_name} after {max_retries + 1} attempts: {e}")
                        else:
                            print(f"⚠️ Retry {attempt + 1}/{max_retries} for directory {_name}: {e}")
                            time.sleep(1)  # Brief delay before retry

                structure[_name] = {
                    'type': 'directory',
                    'link': _link,
                    'children': children
                }
        except Exception as e:
            print(f"⚠️ Error processing tree item: {e}")
            continue

    return structure


def get_socket_data(package_manager, package_name, specific_versions=None):
    """Get socket data using ZenRows proxy to access Socket.dev."""
    package_manager = PACKAGE_MANAGER_MAP.get(package_manager.lower(), package_manager.lower())
    url = f"https://socket.dev/{package_manager}/package/{package_name}"

    try:
        # Use ZenRows to fetch the Socket.dev page
        print(f"🌐 Fetching Socket.dev data via ZenRows for {package_name}...")
        response = zenrows_request(url, js_render=True)  # Enable JS rendering for dynamic content

        # Parse HTML response
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find version selector in the HTML
        version_selector = soup.find('div', {'data-testid': 'version-selector'})
        if not version_selector:
            # Try alternative selector patterns
            version_selector = soup.find('select', {'id': 'version-selector'}) or \
                               soup.find('div', {'class': lambda x: x and 'version' in x.lower()})

        if not version_selector:
            print(f"⚠️ Could not find version selector in HTML for {package_name}")
            return {"message": "Version selector not found in page"}

        # Extract versions
        versions = version_selector.find_all('option')
        if not versions:
            # Try to find versions in other ways (e.g., list items)
            versions = version_selector.find_all('li') or version_selector.find_all('a')

        if not versions:
            return {"message": "No versions found in version selector"}

        all_versions = []
        suspicious_versions = []

        for version_elem in versions:
            # Extract version number and check if unpublished
            version_text = version_elem.text.strip()
            version_value = version_elem.get('value', version_text)

            # Clean up version value (remove extra text)
            if ' ' in version_value:
                version_value = version_value.split(' ')[0]

            all_versions.append(version_value)

            # Check if this version is marked as unpublished/suspicious
            if 'unpublished' in version_text.lower():
                suspicious_versions.append(version_value)

        # Handle specific versions filter
        if specific_versions:
            suspicious_versions = [v for v in specific_versions if v in all_versions]

        print(f"📦 Found {len(all_versions)} total versions, {len(suspicious_versions)} suspicious")

        # Optimized: prioritize suspicious versions, minimal fallback
        if suspicious_versions:
            versions_to_check = suspicious_versions  # Only check suspicious versions
            print(f"🎯 Checking {len(suspicious_versions)} suspicious versions only")
        else:
            # Only check first 2 versions if no suspicious ones found
            versions_to_check = all_versions[:2]
            print(f"🔍 No suspicious versions, checking first {len(versions_to_check)} versions")

        if not versions_to_check:
            return {"message": "No versions to check"}

        # Try to fetch repository structure for versions (prioritize suspicious ones first)
        for version in versions_to_check:
            print(f"🔍 Fetching repository structure for {package_name} version {version}...")
            repo_structure = get_repository_structure(package_manager, package_name, version)
            if repo_structure:
                return {
                    "package_name": package_name,
                    "package_manager": package_manager,
                    "suspicious_versions": suspicious_versions,
                    "checked_versions": versions_to_check,
                    "repository_structure": repo_structure,
                    "analysis_mode": "suspicious" if suspicious_versions else "all_versions",
                    "total_versions": len(all_versions)
                }

        # If we get here, we found versions but couldn't get repository structures
        return {
            "package_name": package_name,
            "package_manager": package_manager,
            "suspicious_versions": suspicious_versions,
            "checked_versions": versions_to_check,
            "analysis_mode": "suspicious" if suspicious_versions else "all_versions",
            "total_versions": len(all_versions),
            "message": "No repository structure found"
        }

    except Exception as e:
        print(f"❌ Error fetching Socket.dev data for {package_name}: {e}")
        return {"message": f"Failed to fetch data: {e}"}


if __name__ == '__main__':
    try:
        # Load advisories
        with open(ADVISORIES_FILE, 'r') as f:
            advisories = json.load(f)

        print(f"📋 Loaded {len(advisories)} advisories")
        
        # Initialize queue manager to check existing progress
        queue_manager = PackageQueueManager()
        
        # Print initial status
        print_queue_status()
        
        # Check if we have failed jobs to retry
        failed_jobs = queue_manager.get_failed_jobs()
        if failed_jobs:
            print(f"⚠️ Found {len(failed_jobs)} failed packages from previous run")
            retry = input("Retry failed packages? (y/n): ")
            if retry.lower() == 'y':
                retry_failed_packages()
        
        # Process advisories in chunks for memory efficiency
        chunk_size = 100  # Process 100 at a time
        total_processed = 0
        total_failed = 0
        
        print(f"🚀 Starting concurrent processing with chunk size {chunk_size}")
        
        for i in range(0, len(advisories), chunk_size):
            chunk = advisories[i:i+chunk_size]
            chunk_num = (i // chunk_size) + 1
            total_chunks = (len(advisories) + chunk_size - 1) // chunk_size
            
            print(f"\n📦 Processing chunk {chunk_num}/{total_chunks} ({len(chunk)} advisories)")
            
            # Process chunk concurrently
            successful, failed = process_advisories_concurrent(
                chunk,
                get_socket_data_func=get_socket_data,
                normalize_func=normalize_item,
                enrich_func=enrich_item,
                max_workers=15  # Adjust based on your ZenRows plan
            )
            
            total_processed += successful
            total_failed += failed
            
            # Print progress
            print(f"✅ Chunk complete: {successful} successful, {failed} failed")
            print_queue_status()
            
            # Optional: pause between chunks to avoid overwhelming the API
            if chunk_num < total_chunks:
                print("⏸️ Pausing between chunks...")
                time.sleep(2)
        
        # Print final summary
        print("\n" + "="*60)
        print("📊 FINAL SUMMARY")
        print("="*60)
        print(f"Total advisories: {len(advisories)}")
        print(f"Successfully processed: {total_processed}")
        print(f"Failed: {total_failed}")
        print_queue_status()
        
        # Check if there are any remaining failed jobs
        final_failed = queue_manager.get_failed_jobs()
        if final_failed:
            print(f"\n⚠️ {len(final_failed)} packages failed and may need manual review")
            print("Failed packages:")
            for job_id, job in list(final_failed.items())[:10]:  # Show first 10
                print(f"  - {job_id}: {job.error}")
            if len(final_failed) > 10:
                print(f"  ... and {len(final_failed) - 10} more")
        
        print("\n✅ Processing complete!")
        
    except KeyboardInterrupt:
        print("\n🛑 Received interrupt signal, shutting down gracefully...")
        print("Progress has been saved and can be resumed on next run.")
    except FileNotFoundError:
        print(f"❌ Advisory file not found: {ADVISORIES_FILE}")
        print("Please run the scraper to fetch advisories first.")
    except Exception as e:
        print(f"❌ Error in main process: {e}")
        import traceback
        traceback.print_exc()