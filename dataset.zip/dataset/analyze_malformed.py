#!/usr/bin/env python3
"""
Analyze existing package JSON files to identify malformed entries that need re-processing.
"""

import json
import os
from pathlib import Path
from collections import defaultdict
from tqdm import tqdm

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PACKAGES_DIR = os.path.join(SCRIPT_DIR, 'packages')

def analyze_package_file(file_path):
    """Analyze a single package file for malformation issues."""
    issues = []
    
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        socket_data = data.get('socket_data', {})
        
        # Check if socket_data indicates no data was found
        if socket_data.get('message'):
            issues.append(f"message: {socket_data['message']}")
            return issues
        
        repo_structure = socket_data.get('repository_structure', {})
        
        # If no repository structure, that's an issue
        if not repo_structure:
            issues.append("no_repository_structure")
            return issues
        
        # Analyze repository structure
        stats = {
            'total_items': 0,
            'files': 0,
            'dirs': 0,
            'files_with_raw': 0,
            'files_without_raw': 0,
            'dirs_with_children': 0,
            'dirs_without_children': 0,
            'mixed_link_types': False,
            'link_types': set()
        }
        
        def analyze_structure(structure, depth=0):
            for name, item in structure.items():
                stats['total_items'] += 1
                
                if item.get('type') == 'file':
                    stats['files'] += 1
                    raw_link = item.get('raw_link')
                    
                    if raw_link:
                        stats['files_with_raw'] += 1
                        # Check link type
                        if '/blob/' in raw_link:
                            stats['link_types'].add('blob')
                        elif '/files/' in raw_link:
                            stats['link_types'].add('files')
                        else:
                            stats['link_types'].add('other')
                    else:
                        stats['files_without_raw'] += 1
                        
                elif item.get('type') == 'directory':
                    stats['dirs'] += 1
                    children = item.get('children', {})
                    
                    if children:
                        stats['dirs_with_children'] += 1
                        analyze_structure(children, depth + 1)
                    else:
                        stats['dirs_without_children'] += 1
        
        analyze_structure(repo_structure)
        
        # Identify issues
        if len(stats['link_types']) > 1:
            issues.append(f"mixed_link_types: {stats['link_types']}")
        
        if stats['files_without_raw'] > 0:
            issues.append(f"files_without_raw: {stats['files_without_raw']}/{stats['files']}")
        
        if stats['dirs'] > 0 and stats['dirs_without_children'] == stats['dirs']:
            issues.append(f"all_dirs_empty: {stats['dirs']}")
        elif stats['dirs_without_children'] > 0:
            issues.append(f"some_dirs_empty: {stats['dirs_without_children']}/{stats['dirs']}")
        
        # Check for suspicious versions but no structure
        suspicious = socket_data.get('suspicious_versions', [])
        if suspicious and stats['total_items'] == 0:
            issues.append(f"suspicious_but_no_structure")
            
    except json.JSONDecodeError:
        issues.append("invalid_json")
    except Exception as e:
        issues.append(f"error: {str(e)}")
    
    return issues

def main():
    """Main analysis function."""
    print("🔍 Analyzing existing package files for malformation...")
    print("=" * 60)
    
    # Find all JSON files
    json_files = []
    for root, dirs, files in os.walk(PACKAGES_DIR):
        for file in files:
            if file.endswith('.json'):
                json_files.append(os.path.join(root, file))
    
    print(f"Found {len(json_files)} JSON files to analyze")
    
    # Analyze each file
    malformed = defaultdict(list)
    issue_counts = defaultdict(int)
    
    for file_path in tqdm(json_files, desc="Analyzing files"):
        issues = analyze_package_file(file_path)
        
        if issues:
            # Extract package info from path
            rel_path = os.path.relpath(file_path, PACKAGES_DIR)
            parts = rel_path.split(os.sep)
            
            if len(parts) >= 2:
                package_manager = parts[0]
                package_file = parts[-1]
                package_name = package_file[:-5]  # Remove .json
                
                malformed[(package_manager, package_name)] = {
                    'file': file_path,
                    'issues': issues
                }
                
                for issue in issues:
                    issue_type = issue.split(':')[0]
                    issue_counts[issue_type] += 1
    
    # Print summary
    print(f"\n📊 Analysis Results:")
    print(f"Total files: {len(json_files)}")
    print(f"Malformed files: {len(malformed)}")
    print(f"Percentage malformed: {len(malformed) / len(json_files) * 100:.1f}%")
    
    print(f"\n🔍 Issue Breakdown:")
    for issue_type, count in sorted(issue_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {issue_type}: {count}")
    
    # Save malformed list for re-processing
    malformed_list = []
    for (pm, name), info in malformed.items():
        malformed_list.append({
            'package_manager': pm,
            'package_name': name,
            'file': info['file'],
            'issues': info['issues']
        })
    
    output_file = os.path.join(SCRIPT_DIR, 'malformed_packages.json')
    with open(output_file, 'w') as f:
        json.dump(malformed_list, f, indent=2)
    
    print(f"\n💾 Saved list of {len(malformed_list)} malformed packages to {output_file}")
    
    # Show some examples
    print(f"\n📦 Examples of malformed packages:")
    for item in malformed_list[:5]:
        print(f"  {item['package_manager']}/{item['package_name']}: {', '.join(item['issues'][:2])}")
    
    return malformed_list

if __name__ == "__main__":
    malformed = main()