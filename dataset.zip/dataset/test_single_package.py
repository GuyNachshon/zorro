#!/usr/bin/env python3
"""
Test script to debug the socket data extraction for a single package.
This will help us understand what's wrong with the batch processing.
"""

import sys
import os
from dotenv import load_dotenv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

load_dotenv()

# Set the ZenRows API key before importing main
# Replace with your actual API key
os.environ['ZENROWS_API_KEY'] = os.getenv('ZENROWS_API_KEY')

from main import get_socket_data, app, PACKAGE_MANAGER_MAP
import json
from pprint import pprint

def test_paypal_invoicing():
    """Test the updated get_socket_data function using direct API calls."""
    print("🧪 Testing new get_socket_data() with direct API calls on paypal-invoicing package...")
    
    package_manager = "npm" 
    package_name = "paypal-invoicing"
    
    print(f"📦 Package: {package_name}")
    print(f"🏗️  Manager: {package_manager}")
    print("-" * 50)
    
    try:
        # Test with no specific versions (should find suspicious ones)
        print("🔍 Testing without specific versions (looking for suspicious)...")
        result = get_socket_data(package_manager, package_name)
        
        print("📊 Result:")
        pprint(result)
        
        # Test with specific version if needed
        print("\n" + "="*50)
        print("🔍 Testing with specific version range...")
        
        # Simulate what the advisory processing would do
        vulnerable_version_range = ">= 0"  # From the JSON file we saw
        specific_versions = None
        
        if vulnerable_version_range and not (">" in vulnerable_version_range or "<" in vulnerable_version_range):
            specific_versions = [v.strip() for v in vulnerable_version_range.replace('>=', '').split(',')]
            print(f"🎯 Specific versions to check: {specific_versions}")
        else:
            print(f"🎯 Version range: {vulnerable_version_range} (no specific versions)")
            
        result_with_versions = get_socket_data(package_manager, package_name, specific_versions)
        print("📊 Result with specific versions:")
        pprint(result_with_versions)
        
    except Exception as e:
        print(f"❌ Error testing package: {e}")
        import traceback
        traceback.print_exc()

def test_socket_url_directly():
    """Test by scraping the Socket.dev URL directly to see what we get."""
    print("\n" + "="*60)
    print("🌐 Testing direct Socket.dev URL scraping...")
    
    package_manager = "npm"
    package_name = "paypal-invoicing" 
    url = f"https://socket.dev/{package_manager}/package/{package_name}"
    
    print(f"🔗 URL: {url}")
    
    try:
        from bs4 import BeautifulSoup
        
        results = app.scrape(url, formats=["html"])
        soup = BeautifulSoup(results.html, 'html.parser')
        
        # Look for version selector
        version_selector = soup.find('div', {'data-testid': 'version-selector'})
        if version_selector:
            versions = version_selector.find_all('option')
            print(f"📋 Found {len(versions)} versions:")
            
            suspicious_versions = []
            all_versions = []
            
            for i, version in enumerate(versions[:10]):  # Show first 10
                version_value = version.get('value', 'N/A')
                version_text = version.text.strip()
                all_versions.append(version_value)
                
                is_suspicious = 'unpublished' in version_text.lower()
                if is_suspicious:
                    suspicious_versions.append(version_value)
                    
                print(f"  {i+1:2d}. {version_value:15s} | {version_text:30s} | {'🚨 SUSPICIOUS' if is_suspicious else '✅ Normal'}")
                
            if len(versions) > 10:
                print(f"  ... and {len(versions) - 10} more versions")
                
            print(f"\n🚨 Total suspicious versions: {len(suspicious_versions)}")
            print(f"📦 Total versions: {len(all_versions)}")
            
            if suspicious_versions:
                print("🚨 Suspicious versions found:")
                for v in suspicious_versions:
                    print(f"   - {v}")
            else:
                print("ℹ️  No explicitly suspicious versions, should fetch all versions")
                
        else:
            print("❌ No version selector found!")
            # Let's see what we did get
            print("📝 HTML snippet:")
            print(results.html[:1000] + "..." if len(results.html) > 1000 else results.html)
            
    except Exception as e:
        print(f"❌ Error scraping URL: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("🔬 Socket.dev Data Extraction Debug")
    print("="*60)
    
    test_paypal_invoicing()
    # test_socket_url_directly()  # Removed - this was using old Firecrawl approach
    
    print("\n" + "="*60)
    print("✅ Debug complete!")