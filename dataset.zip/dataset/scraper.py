import json
import os
from pprint import pprint
import requests
from dotenv import load_dotenv

load_dotenv()

BASE_URL = "https://api.github.com/advisories"
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")


def build_from_scratch(start_page=1):
    url = f"{BASE_URL}?type=malware&per_page=100"
    _next = True
    page = start_page
    while _next:
        if page % 10 == 0:
            print(f"Fetching page {page}...")
        try:
            response = requests.get(url, headers={"Authorization": f"Bearer {GITHUB_TOKEN}"})
            _next = 'next' in response.links
            print(f"Response links: {response.links}")
            url = response.links.get('next', {}).get('url', None)
            response.raise_for_status()
            advisories = response.json()
        except requests.RequestException as e:
            with open("github_advisories_resume.txt.version", "w+") as f:
                f.write(f"{url}")
            print(f"Error fetching page {page}: {e}")
            break
        if not advisories:
            break
        yield advisories
        page += 1


def update_advisories(ghsa_id_stop_condition):
    url = f"{BASE_URL}?type=malware&per_page=100"
    page = 1
    while True:
        if page % 10 == 0:
            print(f"Fetching page {page}...")
        paged_url = f"{url}&page={page}"
        try:
            response = requests.get(paged_url)
            response.raise_for_status()
            advisories = response.json()
        except requests.RequestException as e:
            with open("github_advisories_resume.txt.version", "w+") as f:
                f.write(f"{url}")
            print(f"Error fetching page {page}: {e}")
            break
        if not advisories:
            break
        for advisory in advisories:
            if advisory['ghsa_id'] == ghsa_id_stop_condition:
                print(f"Reached stop condition at {ghsa_id_stop_condition}. Stopping updates.")
                fill_missing = []
                for advisory in advisories:
                    if advisory['ghsa_id'] == ghsa_id_stop_condition:
                        break
                    fill_missing.append(advisory)
                yield from reversed(fill_missing)
            yield advisory
        page += 1


if __name__ == "__main__":
    _all = []
    for page in build_from_scratch():
        _all.extend(page)
        if len(_all) % 20 == 0:
            print(f"Total advisories fetched: {len(_all)}")

    print(f"Fetched {len(_all)} advisories")
    pprint(_all[:2])  # Print first 2 advisories for inspection

    with open("github_advisories.json", "w+") as f:
        json.dump(_all, f, indent=4)

    if _all:
        with open("github_advisories.json.version", "w+") as f:
            f.write(f"{_all[0]['ghsa_id']}")
