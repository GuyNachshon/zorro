# Job Queue System Documentation

## Overview
The updated `scraper-2.py` now includes an asynchronous job queue system for managing Firecrawl batch scraping operations. This system provides:

- Non-blocking batch job submission
- Persistent job tracking with JSON-based queues
- Automatic job monitoring and status updates
- Result processing callbacks
- Periodic cleanup of old jobs and orphaned files

## Architecture

### Core Components

#### 1. **JobQueueManager**
Manages three persistent queues stored as JSON files:
- `pending_jobs.json` - Jobs currently being processed
- `completed_jobs.json` - Successfully completed jobs
- `failed_jobs.json` - Failed jobs with error information

#### 2. **JobMonitor** (Thread)
- Polls Firecrawl API for job status updates
- Moves jobs between queues based on status
- Saves results to `job_results/` directory
- Calls processing callbacks for completed jobs
- Default poll interval: 5 seconds

#### 3. **JobCleaner** (Thread)
- Runs periodic cleanup (default: every hour)
- Removes jobs older than retention period (default: 7 days)
- Cleans up orphaned result files
- Maintains queue hygiene

### Data Flow

1. **Job Submission**
   - `batch_scrape_urls()` or `get_socket_data_batch()` called
   - Uses `app.start_batch_scrape()` to start async job
   - Job ID and metadata saved to pending queue

2. **Job Monitoring**
   - JobMonitor polls Firecrawl API every 5 seconds
   - Updates job status (pending → in_progress → completed/failed)
   - On completion, saves results and calls processing callback

3. **Result Processing**
   - `process_completed_job_results()` processes job data
   - Extracts package/version information
   - Saves results to `packages/{manager}/{package}.json`

## File Structure

```
dataset/
├── jobs/
│   ├── pending_jobs.json      # Active batch jobs
│   ├── completed_jobs.json    # Finished jobs archive  
│   ├── failed_jobs.json       # Failed jobs for debugging
│   └── job_results/           # Raw results from Firecrawl
│       └── {job_id}.json
├── packages/                  # Processed package data
│   ├── npm/
│   ├── pypi/
│   └── cargo/
└── github_advisories.json     # Source advisory data
```

## Usage

### Basic Usage

```python
python dataset/scraper-2.py
```

This will:
1. Load GitHub advisories
2. Submit batch jobs to Firecrawl
3. Monitor jobs asynchronously
4. Process and save results as they complete
5. Show progress and final summary

### Configuration

Key parameters can be adjusted:

```python
# Monitor poll interval (seconds)
monitor = JobMonitor(
    queue_manager=queue_manager,
    firecrawl_app=app,
    poll_interval=5  # Check jobs every 5 seconds
)

# Cleanup settings
cleaner = JobCleaner(
    queue_manager=queue_manager,
    cleanup_interval=3600,  # Run cleanup every hour
    retention_days=7  # Keep jobs for 7 days
)

# Batch size for processing
process_advisories_batch(advisories, queue_manager, batch_size=25)
```

### Testing

Run the test suite to verify queue functionality:

```bash
cd dataset
python test_queue.py
```

## Benefits

1. **Non-blocking Operation**: Submit all jobs immediately without waiting
2. **Resilience**: Jobs persist across script restarts
3. **Monitoring**: Track job progress and handle failures gracefully
4. **Scalability**: Process large datasets without memory issues
5. **Debugging**: Failed jobs are saved with error details
6. **Cleanup**: Automatic removal of old data

## Monitoring

Watch the logs for detailed progress:

```bash
# Enable debug logging
export PYTHONUNBUFFERED=1
python dataset/scraper-2.py 2>&1 | tee scraper.log
```

Check queue status:
```bash
# View pending jobs
cat dataset/jobs/pending_jobs.json | jq .

# View completed jobs  
cat dataset/jobs/completed_jobs.json | jq .

# Check failed jobs
cat dataset/jobs/failed_jobs.json | jq .
```

## Error Handling

- Failed jobs are moved to `failed_jobs.json` with error details
- Jobs older than 24 hours are marked as expired
- Network errors trigger automatic retries (configurable)
- Graceful shutdown on Ctrl+C with queue persistence

## Future Enhancements

- Webhook support for real-time notifications
- Job priority levels
- Distributed processing across multiple workers
- Database backend for larger scale
- Web dashboard for monitoring
- Automatic retry logic for failed jobs