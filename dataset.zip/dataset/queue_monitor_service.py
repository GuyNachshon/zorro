#!/usr/bin/env python3
"""
Standalone queue monitoring service for Firecrawl batch jobs.

This service runs continuously in the background to:
- Monitor pending jobs and check their status
- Process completed job results
- Clean up old jobs and files
- Handle job failures and retries

Usage:
    # Start the service
    python queue_monitor_service.py
    
    # Run in background
    nohup python queue_monitor_service.py > queue_monitor.log 2>&1 &
    
    # With custom settings
    python queue_monitor_service.py --poll-interval 10 --cleanup-interval 1800
"""

import argparse
import signal
import sys
import time
import logging
from datetime import datetime
import json
import os

# Import from scraper_2
from scraper_2 import (
    JobQueueManager,
    JobMonitor,
    JobCleaner,
    process_completed_job_results,
    app,
    PENDING_JOBS_FILE,
    COMPLETED_JOBS_FILE,
    FAILED_JOBS_FILE
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('queue_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('queue_monitor_service')


class QueueMonitorService:
    """Main service class for queue monitoring."""
    
    def __init__(self, poll_interval=5, cleanup_interval=3600, retention_days=7):
        self.queue_manager = JobQueueManager()
        self.poll_interval = poll_interval
        self.cleanup_interval = cleanup_interval
        self.retention_days = retention_days
        self.monitor = None
        self.cleaner = None
        self.running = False
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully."""
        logger.info(f"Received signal {signum}. Shutting down gracefully...")
        self.stop()
        sys.exit(0)
    
    def start(self):
        """Start the monitoring service."""
        logger.info("=" * 60)
        logger.info("Starting Queue Monitor Service")
        logger.info(f"Poll interval: {self.poll_interval}s")
        logger.info(f"Cleanup interval: {self.cleanup_interval}s")
        logger.info(f"Retention days: {self.retention_days}")
        logger.info("=" * 60)
        
        # Create and start monitor thread
        self.monitor = JobMonitor(
            queue_manager=self.queue_manager,
            firecrawl_app=app,
            poll_interval=self.poll_interval,
            process_callback=process_completed_job_results
        )
        self.monitor.start()
        logger.info("✓ Job monitor thread started")
        
        # Create and start cleanup thread
        self.cleaner = JobCleaner(
            queue_manager=self.queue_manager,
            cleanup_interval=self.cleanup_interval,
            retention_days=self.retention_days
        )
        self.cleaner.start()
        logger.info("✓ Job cleaner thread started")
        
        self.running = True
        self.run_main_loop()
    
    def run_main_loop(self):
        """Main service loop that provides status updates."""
        logger.info("Service is running. Press Ctrl+C to stop.")
        
        last_status_time = 0
        status_interval = 60  # Print status every minute
        
        while self.running:
            try:
                current_time = time.time()
                
                # Print periodic status update
                if current_time - last_status_time > status_interval:
                    self.print_status()
                    last_status_time = current_time
                
                # Check thread health
                if not self.monitor.is_alive():
                    logger.error("Monitor thread died! Restarting...")
                    self.restart_monitor()
                
                if not self.cleaner.is_alive():
                    logger.error("Cleaner thread died! Restarting...")
                    self.restart_cleaner()
                
                time.sleep(10)  # Check every 10 seconds
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(10)
    
    def print_status(self):
        """Print current queue status."""
        try:
            pending = self.queue_manager.get_pending_jobs()
            completed = self.queue_manager._read_queue(COMPLETED_JOBS_FILE)
            failed = self.queue_manager._read_queue(FAILED_JOBS_FILE)
            
            # Count jobs by status
            pending_count = len(pending)
            in_progress = sum(1 for j in pending.values() if j.status.value == 'in_progress')
            waiting = pending_count - in_progress
            
            logger.info("-" * 40)
            logger.info(f"Queue Status at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            logger.info(f"  Pending: {waiting} waiting, {in_progress} in progress")
            logger.info(f"  Completed: {len(completed)} jobs")
            logger.info(f"  Failed: {len(failed)} jobs")
            logger.info(f"  Monitor: {'Active' if self.monitor.is_alive() else 'Dead'}")
            logger.info(f"  Cleaner: {'Active' if self.cleaner.is_alive() else 'Dead'}")
            logger.info("-" * 40)
            
        except Exception as e:
            logger.error(f"Error printing status: {e}")
    
    def restart_monitor(self):
        """Restart the monitor thread if it dies."""
        try:
            if self.monitor:
                self.monitor.stop()
                self.monitor.join(timeout=5)
            
            self.monitor = JobMonitor(
                queue_manager=self.queue_manager,
                firecrawl_app=app,
                poll_interval=self.poll_interval,
                process_callback=process_completed_job_results
            )
            self.monitor.start()
            logger.info("Monitor thread restarted successfully")
            
        except Exception as e:
            logger.error(f"Failed to restart monitor: {e}")
    
    def restart_cleaner(self):
        """Restart the cleaner thread if it dies."""
        try:
            if self.cleaner:
                self.cleaner.stop()
                self.cleaner.join(timeout=5)
            
            self.cleaner = JobCleaner(
                queue_manager=self.queue_manager,
                cleanup_interval=self.cleanup_interval,
                retention_days=self.retention_days
            )
            self.cleaner.start()
            logger.info("Cleaner thread restarted successfully")
            
        except Exception as e:
            logger.error(f"Failed to restart cleaner: {e}")
    
    def stop(self):
        """Stop the monitoring service."""
        logger.info("Stopping Queue Monitor Service...")
        self.running = False
        
        if self.monitor:
            self.monitor.stop()
            self.monitor.join(timeout=5)
            logger.info("✓ Monitor thread stopped")
        
        if self.cleaner:
            self.cleaner.stop()
            self.cleaner.join(timeout=5)
            logger.info("✓ Cleaner thread stopped")
        
        logger.info("Queue Monitor Service stopped")
    
    def get_stats(self):
        """Get detailed statistics about the queues."""
        stats = {
            'timestamp': datetime.now().isoformat(),
            'queues': {},
            'threads': {
                'monitor': 'active' if self.monitor and self.monitor.is_alive() else 'dead',
                'cleaner': 'active' if self.cleaner and self.cleaner.is_alive() else 'dead'
            }
        }
        
        # Get queue stats
        for queue_name, queue_file in [
            ('pending', PENDING_JOBS_FILE),
            ('completed', COMPLETED_JOBS_FILE),
            ('failed', FAILED_JOBS_FILE)
        ]:
            jobs = self.queue_manager._read_queue(queue_file)
            stats['queues'][queue_name] = {
                'count': len(jobs),
                'jobs': []
            }
            
            for job_id, job in jobs.items():
                job_info = {
                    'id': job_id,
                    'type': job.job_type,
                    'status': job.status.value,
                    'created': job.created_at,
                    'updated': job.updated_at
                }
                if job.error:
                    job_info['error'] = job.error
                stats['queues'][queue_name]['jobs'].append(job_info)
        
        return stats


def main():
    """Main entry point for the service."""
    parser = argparse.ArgumentParser(description='Queue Monitor Service for Firecrawl batch jobs')
    parser.add_argument('--poll-interval', type=int, default=5,
                        help='Job polling interval in seconds (default: 5)')
    parser.add_argument('--cleanup-interval', type=int, default=3600,
                        help='Cleanup interval in seconds (default: 3600)')
    parser.add_argument('--retention-days', type=int, default=7,
                        help='Days to retain completed jobs (default: 7)')
    parser.add_argument('--status', action='store_true',
                        help='Show current queue status and exit')
    parser.add_argument('--stats-file', type=str,
                        help='Write detailed stats to JSON file')
    
    args = parser.parse_args()
    
    service = QueueMonitorService(
        poll_interval=args.poll_interval,
        cleanup_interval=args.cleanup_interval,
        retention_days=args.retention_days
    )
    
    if args.status:
        # Just show status and exit
        service.print_status()
        
        if args.stats_file:
            stats = service.get_stats()
            with open(args.stats_file, 'w') as f:
                json.dump(stats, f, indent=2)
            logger.info(f"Stats written to {args.stats_file}")
        
        sys.exit(0)
    
    # Start the service
    try:
        service.start()
    except Exception as e:
        logger.error(f"Service failed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()