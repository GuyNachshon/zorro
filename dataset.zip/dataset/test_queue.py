#!/usr/bin/env python3
"""Test script for the job queue system."""

import json
import os
import sys
from datetime import datetime, timedelta
import time

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the classes we want to test
from scraper_2 import (
    JobQueueManager, JobStatus, BatchJob, 
    PENDING_JOBS_FILE, COMPLETED_JOBS_FILE, FAILED_JOBS_FILE
)


def test_queue_manager():
    """Test basic queue manager functionality."""
    print("Testing JobQueueManager...")
    
    # Create manager
    manager = JobQueueManager()
    
    # Create a test job
    test_job = BatchJob(
        job_id="test-job-001",
        job_type="test_scrape",
        urls=["https://example.com"],
        status=JobStatus.PENDING,
        created_at=datetime.now().isoformat(),
        updated_at=datetime.now().isoformat(),
        batch_info={"test": True},
        metadata={"test_data": "hello"},
        expires_at=(datetime.now() + timedelta(hours=1)).isoformat()
    )
    
    # Add to pending queue
    print("Adding job to pending queue...")
    manager.add_pending_job(test_job)
    
    # Check pending jobs
    pending = manager.get_pending_jobs()
    assert "test-job-001" in pending, "Job not found in pending queue"
    print(f"✓ Job added to pending queue: {len(pending)} pending jobs")
    
    # Update status
    manager.update_job_status("test-job-001", JobStatus.IN_PROGRESS)
    pending = manager.get_pending_jobs()
    assert pending["test-job-001"].status == JobStatus.IN_PROGRESS, "Status not updated"
    print("✓ Job status updated to IN_PROGRESS")
    
    # Move to completed
    manager.move_to_completed("test-job-001", results_file="/tmp/test_results.json")
    pending = manager.get_pending_jobs()
    completed = manager._read_queue(COMPLETED_JOBS_FILE)
    
    assert "test-job-001" not in pending, "Job still in pending queue"
    assert "test-job-001" in completed, "Job not in completed queue"
    print(f"✓ Job moved to completed queue: {len(completed)} completed jobs")
    
    # Create another test job to test failure
    fail_job = BatchJob(
        job_id="test-job-002",
        job_type="test_scrape",
        urls=["https://fail.example.com"],
        status=JobStatus.PENDING,
        created_at=datetime.now().isoformat(),
        updated_at=datetime.now().isoformat(),
        batch_info={"test": True},
        metadata={"test_data": "fail"},
        expires_at=(datetime.now() + timedelta(hours=1)).isoformat()
    )
    
    manager.add_pending_job(fail_job)
    manager.move_to_failed("test-job-002", "Simulated failure")
    
    failed = manager._read_queue(FAILED_JOBS_FILE)
    assert "test-job-002" in failed, "Job not in failed queue"
    assert failed["test-job-002"].error == "Simulated failure", "Error message not saved"
    print(f"✓ Job moved to failed queue: {len(failed)} failed jobs")
    
    # Test cleanup (create old job)
    old_job = BatchJob(
        job_id="old-job-001",
        job_type="test_scrape",
        urls=["https://old.example.com"],
        status=JobStatus.COMPLETED,
        created_at=(datetime.now() - timedelta(days=10)).isoformat(),
        updated_at=(datetime.now() - timedelta(days=10)).isoformat(),
        batch_info={"test": True},
        metadata=None
    )
    
    # Manually add old job to completed
    completed = manager._read_queue(COMPLETED_JOBS_FILE)
    completed["old-job-001"] = old_job
    manager._write_queue(COMPLETED_JOBS_FILE, completed)
    
    # Run cleanup
    manager.cleanup_expired_jobs(retention_days=7)
    
    completed = manager._read_queue(COMPLETED_JOBS_FILE)
    assert "old-job-001" not in completed, "Old job not cleaned up"
    print("✓ Old jobs cleaned up successfully")
    
    print("\n✅ All queue manager tests passed!")
    
    # Clean up test files
    for job_id in ["test-job-001", "test-job-002"]:
        completed = manager._read_queue(COMPLETED_JOBS_FILE)
        if job_id in completed:
            del completed[job_id]
            manager._write_queue(COMPLETED_JOBS_FILE, completed)
        
        failed = manager._read_queue(FAILED_JOBS_FILE)
        if job_id in failed:
            del failed[job_id]
            manager._write_queue(FAILED_JOBS_FILE, failed)
    
    print("🧹 Test cleanup completed")


if __name__ == "__main__":
    try:
        test_queue_manager()
        print("\n🎉 All tests passed successfully!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)