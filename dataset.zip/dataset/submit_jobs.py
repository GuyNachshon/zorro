#!/usr/bin/env python3
"""
Submit batch scraping jobs to the queue without blocking.

This script allows you to submit jobs that will be processed by the 
queue_monitor_service running in the background.

Usage:
    # Submit all advisories
    python submit_jobs.py
    
    # Submit a subset
    python submit_jobs.py --limit 10
    
    # Submit specific batch size
    python submit_jobs.py --batch-size 50
"""

import argparse
import json
import sys
import os
from datetime import datetime

# Import from scraper_2
from scraper_2 import (
    JobQueueManager, 
    process_advisories_batch,
    ADVISORIES_FILE,
    PENDING_JOBS_FILE,
    COMPLETED_JOBS_FILE,
    FAILED_JOBS_FILE
)


def check_monitor_status():
    """Check if the queue monitor service is running."""
    # Simple check: see if there's a recent update to the pending jobs file
    if os.path.exists(PENDING_JOBS_FILE):
        mod_time = os.path.getmtime(PENDING_JOBS_FILE)
        age_seconds = datetime.now().timestamp() - mod_time
        if age_seconds < 60:  # Modified in last minute
            return True
    return False


def main():
    parser = argparse.ArgumentParser(description='Submit batch scraping jobs to the queue')
    parser.add_argument('--limit', type=int, default=None,
                        help='Limit number of advisories to process')
    parser.add_argument('--batch-size', type=int, default=25,
                        help='Number of items per batch job (default: 25)')
    parser.add_argument('--check-monitor', action='store_true',
                        help='Check if monitor service is running')
    parser.add_argument('--status', action='store_true',
                        help='Show queue status')
    
    args = parser.parse_args()
    
    # Initialize queue manager
    queue_manager = JobQueueManager()
    
    if args.status:
        # Show current queue status
        pending = queue_manager.get_pending_jobs()
        completed = queue_manager._read_queue(COMPLETED_JOBS_FILE)
        failed = queue_manager._read_queue(FAILED_JOBS_FILE)
        
        print("📊 Queue Status:")
        print(f"  - Pending: {len(pending)} jobs")
        print(f"  - Completed: {len(completed)} jobs")
        print(f"  - Failed: {len(failed)} jobs")
        
        if pending:
            print("\n⏳ Pending Jobs:")
            for job_id, job in list(pending.items())[:5]:  # Show first 5
                print(f"  - {job_id}: {job.job_type} ({job.status.value})")
            if len(pending) > 5:
                print(f"  ... and {len(pending) - 5} more")
        
        sys.exit(0)
    
    if args.check_monitor:
        if check_monitor_status():
            print("✅ Queue monitor appears to be running")
        else:
            print("⚠️ Queue monitor may not be running")
            print("Start it with: python queue_monitor_service.py")
    
    # Load advisories
    print(f"📂 Loading advisories from {ADVISORIES_FILE}...")
    with open(ADVISORIES_FILE, 'r') as f:
        advisories = json.load(f)
    
    # Apply limit if specified
    if args.limit:
        advisories = advisories[:args.limit]
        print(f"📝 Limited to {len(advisories)} advisories")
    
    print(f"🚀 Submitting batch jobs for {len(advisories)} advisories...")
    print(f"📦 Batch size: {args.batch_size} items per job")
    
    # Process and submit jobs
    process_result = process_advisories_batch(
        advisories, 
        queue_manager, 
        batch_size=args.batch_size
    )
    
    jobs_submitted = process_result['jobs']
    items_to_process = process_result['items']
    
    print(f"\n✅ Successfully submitted:")
    print(f"  - {len(jobs_submitted)} batch jobs")
    print(f"  - {len(items_to_process)} total items")
    
    if jobs_submitted:
        print(f"\n📋 Submitted Job IDs:")
        for job_info in jobs_submitted[:5]:  # Show first 5
            print(f"  - {job_info['job_id']}")
        if len(jobs_submitted) > 5:
            print(f"  ... and {len(jobs_submitted) - 5} more")
    
    # Check pending queue
    pending = queue_manager.get_pending_jobs()
    print(f"\n📊 Current queue: {len(pending)} pending jobs")
    
    if not check_monitor_status():
        print("\n⚠️ Warning: Queue monitor may not be running!")
        print("Jobs have been queued but won't be processed until you start the monitor:")
        print("  python queue_monitor_service.py")
    else:
        print("\n✅ Jobs submitted successfully and will be processed by the monitor service")
        print("Check progress with: python submit_jobs.py --status")
        print("View logs: tail -f queue_monitor.log")


if __name__ == '__main__':
    main()