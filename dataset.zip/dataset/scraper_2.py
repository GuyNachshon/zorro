from pprint import pprint
import urllib
import requests
from scraper import build_from_scratch, update_advisories
import json
import os
from bs4 import BeautifulSoup
from firecrawl import Firecrawl
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
from dataclasses import dataclass, asdict
from enum import Enum

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, 'packages')
ADVISORIES_FILE = os.path.join(SCRIPT_DIR, 'github_advisories.json')
JOBS_DIR = os.path.join(SCRIPT_DIR, 'jobs')
PENDING_JOBS_FILE = os.path.join(JOBS_DIR, 'pending_jobs.json')
COMPLETED_JOBS_FILE = os.path.join(JOBS_DIR, 'completed_jobs.json')
FAILED_JOBS_FILE = os.path.join(JOBS_DIR, 'failed_jobs.json')
JOB_RESULTS_DIR = os.path.join(JOBS_DIR, 'job_results')

# Create necessary directories
os.makedirs(JOBS_DIR, exist_ok=True)
os.makedirs(JOB_RESULTS_DIR, exist_ok=True)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Firecrawl(api_key="fc-76af2aef6d824a82891b2891e4af0a33")

PACKAGE_MANAGER_MAP = {
    'npm': 'npm',
    'pip': 'pypi',
    'rust': 'cargo'
}


class JobStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


@dataclass
class BatchJob:
    job_id: str
    job_type: str  # 'url_scrape' or 'socket_scrape'
    urls: List[str]
    status: JobStatus
    created_at: str
    updated_at: str
    batch_info: Dict[str, Any]
    metadata: Dict[str, Any] = None
    error: str = None
    results_file: str = None
    expires_at: str = None

    def to_dict(self):
        data = asdict(self)
        data['status'] = self.status.value
        return data

    @classmethod
    def from_dict(cls, data):
        data['status'] = JobStatus(data['status'])
        return cls(**data)


class JobQueueManager:
    """Manages persistent job queues for batch scraping operations."""

    def __init__(self):
        self.lock = threading.Lock()
        self._ensure_queue_files()

    def _ensure_queue_files(self):
        """Ensure queue files exist."""
        for file_path in [PENDING_JOBS_FILE, COMPLETED_JOBS_FILE, FAILED_JOBS_FILE]:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    json.dump({}, f)

    def _read_queue(self, file_path: str) -> Dict[str, BatchJob]:
        """Read jobs from a queue file."""
        with self.lock:
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    return {
                        job_id: BatchJob.from_dict(job_data)
                        for job_id, job_data in data.items()
                    }
            except (FileNotFoundError, json.JSONDecodeError):
                return {}

    def _write_queue(self, file_path: str, jobs: Dict[str, BatchJob]):
        """Write jobs to a queue file."""
        with self.lock:
            with open(file_path, 'w') as f:
                data = {job_id: job.to_dict() for job_id, job in jobs.items()}
                json.dump(data, f, indent=2)

    def add_pending_job(self, job: BatchJob):
        """Add a job to the pending queue."""
        jobs = self._read_queue(PENDING_JOBS_FILE)
        jobs[job.job_id] = job
        self._write_queue(PENDING_JOBS_FILE, jobs)
        logger.info(f"Added job {job.job_id} to pending queue")

    def get_pending_jobs(self) -> Dict[str, BatchJob]:
        """Get all pending jobs."""
        return self._read_queue(PENDING_JOBS_FILE)

    def move_to_completed(self, job_id: str, results_file: str = None):
        """Move a job from pending to completed."""
        pending = self._read_queue(PENDING_JOBS_FILE)
        completed = self._read_queue(COMPLETED_JOBS_FILE)

        if job_id in pending:
            job = pending[job_id]
            job.status = JobStatus.COMPLETED
            job.updated_at = datetime.now().isoformat()
            if results_file:
                job.results_file = results_file

            completed[job_id] = job
            del pending[job_id]

            self._write_queue(PENDING_JOBS_FILE, pending)
            self._write_queue(COMPLETED_JOBS_FILE, completed)
            logger.info(f"Moved job {job_id} to completed queue")

    def move_to_failed(self, job_id: str, error: str):
        """Move a job from pending to failed."""
        pending = self._read_queue(PENDING_JOBS_FILE)
        failed = self._read_queue(FAILED_JOBS_FILE)

        if job_id in pending:
            job = pending[job_id]
            job.status = JobStatus.FAILED
            job.updated_at = datetime.now().isoformat()
            job.error = error

            failed[job_id] = job
            del pending[job_id]

            self._write_queue(PENDING_JOBS_FILE, pending)
            self._write_queue(FAILED_JOBS_FILE, failed)
            logger.error(f"Moved job {job_id} to failed queue: {error}")

    def update_job_status(self, job_id: str, status: JobStatus):
        """Update the status of a pending job."""
        jobs = self._read_queue(PENDING_JOBS_FILE)
        if job_id in jobs:
            jobs[job_id].status = status
            jobs[job_id].updated_at = datetime.now().isoformat()
            self._write_queue(PENDING_JOBS_FILE, jobs)

    def cleanup_expired_jobs(self, retention_days: int = 7):
        """Clean up old completed and failed jobs."""
        cutoff_date = datetime.now() - timedelta(days=retention_days)

        for file_path in [COMPLETED_JOBS_FILE, FAILED_JOBS_FILE]:
            jobs = self._read_queue(file_path)
            jobs_to_keep = {}

            for job_id, job in jobs.items():
                job_date = datetime.fromisoformat(job.updated_at)
                if job_date > cutoff_date:
                    jobs_to_keep[job_id] = job
                else:
                    # Delete associated results file if it exists
                    if job.results_file and os.path.exists(job.results_file):
                        os.remove(job.results_file)
                        logger.info(f"Deleted old results file: {job.results_file}")

            if len(jobs_to_keep) < len(jobs):
                self._write_queue(file_path, jobs_to_keep)
                logger.info(f"Cleaned up {len(jobs) - len(jobs_to_keep)} old jobs from {file_path}")


class JobMonitor(threading.Thread):
    """Monitor thread for tracking batch scrape job status."""

    def __init__(self, queue_manager: JobQueueManager, firecrawl_app: Firecrawl,
                 poll_interval: int = 5, process_callback=None):
        super().__init__(daemon=True)
        self.queue_manager = queue_manager
        self.app = firecrawl_app
        self.poll_interval = poll_interval
        self.process_callback = process_callback
        self.stop_event = threading.Event()
        self.active_jobs = {}  # Track jobs being monitored

    def run(self):
        """Main monitoring loop."""
        logger.info("JobMonitor started")

        while not self.stop_event.is_set():
            try:
                self._check_pending_jobs()
                self.stop_event.wait(self.poll_interval)
            except Exception as e:
                logger.error(f"Error in JobMonitor: {e}")
                self.stop_event.wait(self.poll_interval)

        logger.info("JobMonitor stopped")

    def _check_pending_jobs(self):
        """Check status of all pending jobs."""
        pending_jobs = self.queue_manager.get_pending_jobs()

        for job_id, job in pending_jobs.items():
            try:
                # Check if job has expired (>24 hours)
                if job.expires_at:
                    expires = datetime.fromisoformat(job.expires_at)
                    if datetime.now() > expires:
                        self.queue_manager.move_to_failed(job_id, "Job expired (>24 hours)")
                        continue

                # Get job status from Firecrawl
                status = self.app.get_batch_scrape_status(job_id)

                if status.get('status') == 'completed':
                    self._handle_completed_job(job_id, job, status)
                elif status.get('status') == 'failed':
                    error_msg = status.get('error', 'Unknown error')
                    self.queue_manager.move_to_failed(job_id, error_msg)
                elif status.get('status') in ['in_progress', 'processing']:
                    # Update job status
                    self.queue_manager.update_job_status(job_id, JobStatus.IN_PROGRESS)
                    logger.debug(f"Job {job_id} is still in progress: {status.get('completed', 0)}/{status.get('total', 0)}")

            except Exception as e:
                logger.error(f"Error checking job {job_id}: {e}")

    def _handle_completed_job(self, job_id: str, job: BatchJob, status: dict):
        """Handle a completed job."""
        try:
            # Save results to file
            results_file = os.path.join(JOB_RESULTS_DIR, f"{job_id}.json")
            with open(results_file, 'w') as f:
                json.dump(status, f, indent=2)

            # Process results if callback provided
            if self.process_callback and job.job_type == 'url_scrape':
                self.process_callback(job_id, status, job.metadata)
            elif self.process_callback and job.job_type == 'socket_scrape':
                self.process_callback(job_id, status, job.metadata)

            # Move to completed queue
            self.queue_manager.move_to_completed(job_id, results_file)
            logger.info(f"Job {job_id} completed successfully")

        except Exception as e:
            logger.error(f"Error handling completed job {job_id}: {e}")
            self.queue_manager.move_to_failed(job_id, str(e))

    def stop(self):
        """Stop the monitor thread."""
        self.stop_event.set()


class JobCleaner(threading.Thread):
    """Cleanup thread for managing old jobs and results."""

    def __init__(self, queue_manager: JobQueueManager, cleanup_interval: int = 3600,
                 retention_days: int = 7):
        super().__init__(daemon=True)
        self.queue_manager = queue_manager
        self.cleanup_interval = cleanup_interval  # Default: 1 hour
        self.retention_days = retention_days
        self.stop_event = threading.Event()

    def run(self):
        """Main cleanup loop."""
        logger.info(f"JobCleaner started (retention: {self.retention_days} days)")

        while not self.stop_event.is_set():
            try:
                self._perform_cleanup()
                self.stop_event.wait(self.cleanup_interval)
            except Exception as e:
                logger.error(f"Error in JobCleaner: {e}")
                self.stop_event.wait(self.cleanup_interval)

        logger.info("JobCleaner stopped")

    def _perform_cleanup(self):
        """Perform cleanup operations."""
        logger.info("Performing job cleanup...")

        # Clean up old jobs
        self.queue_manager.cleanup_expired_jobs(self.retention_days)

        # Clean up orphaned result files
        self._clean_orphaned_results()

        logger.info("Job cleanup completed")

    def _clean_orphaned_results(self):
        """Remove result files that don't have corresponding jobs."""
        if not os.path.exists(JOB_RESULTS_DIR):
            return

        all_jobs = {}
        for file_path in [PENDING_JOBS_FILE, COMPLETED_JOBS_FILE, FAILED_JOBS_FILE]:
            jobs = self.queue_manager._read_queue(file_path)
            all_jobs.update(jobs)

        referenced_files = {job.results_file for job in all_jobs.values() if job.results_file}

        for file_name in os.listdir(JOB_RESULTS_DIR):
            file_path = os.path.join(JOB_RESULTS_DIR, file_name)
            if file_path not in referenced_files:
                try:
                    os.remove(file_path)
                    logger.info(f"Removed orphaned result file: {file_path}")
                except Exception as e:
                    logger.error(f"Error removing orphaned file {file_path}: {e}")

    def stop(self):
        """Stop the cleaner thread."""
        self.stop_event.set()


def normalize_item(item):
    package_info = item.get("vulnerabilities", [{}])[0].get("package", {})
    return {
        "ghsa_id": item.get("ghsa_id"),
        "summary": item.get("summary"),
        "published": item.get("published_at"),
        "reviewed": item.get("github_reviewed_at"),
        "updated": item.get("updated_at"),
        "source_code_location": item.get("source_code_location", ''),
        "package_name": package_info.get("name"),
        "package_manager": PACKAGE_MANAGER_MAP.get(package_info.get("ecosystem"), package_info.get("ecosystem").lower()),
        "vulnerable_version_range": item.get("vulnerabilities", [{}])[0].get("vulnerable_version_range", ">=0"),
        "vulnerable_functions": item.get("vulnerabilities", [{}])[0].get("vulnerable_functions", []),
        "first_patched_version": item.get("vulnerabilities", [{}])[0].get("first_patched_version"),
    }


def enrich_item(item):
    package_name = item.get("package_name")
    package_manager = item.get("package_manager")
    match package_manager:
        case "npm":
            item["package_url"] = f"https://www.npmjs.com/package/{package_name}"
        case "pypi":
            item["package_url"] = f"https://pypi.org/project/{package_name}"
        case "rubygems":
            item["package_url"] = f"https://rubygems.org/gems/{package_name}"
        case "composer":
            item["package_url"] = f"https://packagist.org/packages/{package_name}"
        case "rust":
            item["package_url"] = f"https://crates.io/crates/{package_name}"
    return item


def batch_scrape_urls(urls, batch_size=50, queue_manager: JobQueueManager = None):
    """Scrape URLs in batches using Firecrawl's batch functionality with job queuing."""
    job_ids = []

    for i in range(0, len(urls), batch_size):
        batch_urls = urls[i:i + batch_size]
        print(f"🔍 Submitting batch {i // batch_size + 1} with {len(batch_urls)} URLs...")

        try:
            # Start batch scrape job (non-blocking)
            job_result = app.start_batch_scrape(
                batch_urls,
                formats=[
                    "html",
                    {
                        "type": "json",
                        "prompt": "Extract version information, unpublished versions, and any suspicious indicators from this package page.",
                        "schema": {
                            "type": "object",
                            "properties": {
                                "versions": {
                                    "type": "array",
                                    "items": {"type": "string"}
                                },
                                "unpublished_versions": {
                                    "type": "array",
                                    "items": {"type": "string"}
                                },
                                "suspicious_indicators": {
                                    "type": "array",
                                    "items": {"type": "string"}
                                }
                            }
                        }
                    }
                ]
            )

            job_id = job_result.id
            if job_id and queue_manager:
                # Create and add job to queue
                job = BatchJob(
                    job_id=job_id,
                    job_type='url_scrape',
                    urls=batch_urls,
                    status=JobStatus.PENDING,
                    created_at=datetime.now().isoformat(),
                    updated_at=datetime.now().isoformat(),
                    batch_info={'batch_index': i // batch_size, 'batch_size': len(batch_urls)},
                    metadata={'url_mapping': {url: idx for idx, url in enumerate(batch_urls)}},
                    expires_at=(datetime.now() + timedelta(hours=24)).isoformat()
                )
                queue_manager.add_pending_job(job)
                job_ids.append(job_id)
                logger.info(f"Started batch job {job_id} for {len(batch_urls)} URLs")

        except Exception as e:
            logger.error(f"Error starting batch scrape: {e}")
            # Could implement fallback to synchronous scraping here if needed

    return job_ids


def build_repo_structure_batch(tree_items, base_url, queue_manager: JobQueueManager = None):
    """Build repository structure using batch operations with job queuing."""
    structure = {}
    urls_to_scrape = []
    url_to_item_map = {}

    # First pass: collect all URLs that need scraping
    for item in tree_items:
        _link = item.find('a', recursive=False).get('href')
        _name = item.find('a', recursive=False).text.strip()
        _type = item.get('data-type')

        if _type == 'file':
            full_url = f"https://github.com{_link}" if not _link.startswith('http') else _link
            urls_to_scrape.append(full_url)
            url_to_item_map[full_url] = {'name': _name, 'type': 'file', 'link': _link}
        elif _type == 'dir':
            full_url = f"https://github.com{_link}" if not _link.startswith('http') else _link
            urls_to_scrape.append(full_url)
            url_to_item_map[full_url] = {'name': _name, 'type': 'directory', 'link': _link}

    if not urls_to_scrape:
        return structure

    # Start batch scrape jobs
    job_ids = batch_scrape_urls(urls_to_scrape, batch_size=25, queue_manager=queue_manager)

    # If queue_manager is provided, jobs will be processed asynchronously
    # Otherwise, we need to wait for them here (fallback to synchronous mode)
    if not queue_manager:
        logger.warning("No queue manager provided, falling back to synchronous scraping")
        # Implement synchronous fallback if needed
        return structure

    # Return structure with job IDs for later processing
    return {'job_ids': job_ids, 'url_mapping': url_to_item_map}


def get_socket_data_batch(package_info_list, queue_manager: JobQueueManager = None):
    """Get socket data for multiple packages using batch operations with job queuing."""
    urls_to_scrape = []
    package_to_url_map = {}

    # Build URLs for batch scraping
    for package_info in package_info_list:
        package_manager = PACKAGE_MANAGER_MAP.get(
            package_info['package_manager'].lower(),
            package_info['package_manager'].lower()
        )
        package_name = package_info['package_name']
        url = f"https://socket.dev/{package_manager}/package/{package_name}"
        urls_to_scrape.append(url)
        package_to_url_map[url] = package_info

    if not urls_to_scrape:
        return {}

    print(f"🔍 Submitting batch scrape for {len(urls_to_scrape)} Socket.dev URLs...")

    # Start batch scrape job with structured extraction
    try:
        job_result = app.start_batch_scrape(
            urls_to_scrape,
            formats=[
                "html",
                {
                    "type": "json",
                    "prompt": "Extract all available versions from the version selector dropdown, identifying any unpublished or suspicious versions.",
                    "schema": {
                        "type": "object",
                        "properties": {
                            "versions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "All available versions"
                            },
                            "unpublished_versions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Versions marked as unpublished i.e 'unpublished' in version.text.lower()"
                            },
                            "suspicious_versions": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Versions that appear suspicious"
                            }
                        }
                    }
                }
            ]
        )

        job_id = job_result.id
        if job_id and queue_manager:
            # Create and add job to queue
            job = BatchJob(
                job_id=job_id,
                job_type='socket_scrape',
                urls=urls_to_scrape,
                status=JobStatus.PENDING,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                batch_info={'total_packages': len(package_info_list)},
                metadata={'package_mapping': package_to_url_map},
                expires_at=(datetime.now() + timedelta(hours=24)).isoformat()
            )
            queue_manager.add_pending_job(job)
            logger.info(f"Started Socket.dev batch job {job_id} for {len(urls_to_scrape)} packages")
            return {'job_id': job_id, 'package_mapping': package_to_url_map}
        elif not queue_manager:
            logger.warning("No queue manager provided, cannot track Socket.dev batch job")
            return {}

    except Exception as e:
        logger.error(f"Error in batch socket scraping: {e}")
        # In async mode with queue manager, we don't fallback
        # The job will be marked as failed by the monitor
        return {}


def process_advisories_batch(advisories, queue_manager: JobQueueManager, batch_size=20):
    """Process advisories in batches with async job handling."""
    all_jobs = []
    normalized_items = []

    for i in range(0, len(advisories), batch_size):
        batch = advisories[i:i + batch_size]
        print(f"📦 Processing advisory batch {i // batch_size + 1} of {len(batch)} items...")

        # Normalize and enrich items
        batch_items = []
        for advisory in batch:
            try:
                item = normalize_item(advisory)
                item = enrich_item(item)
                if item.get("package_name") and item.get("package_manager"):
                    # Prepare specific versions
                    specific_versions = item.get("vulnerable_version_range")
                    if specific_versions and not (">" in specific_versions or "<" in specific_versions):
                        item['specific_versions'] = [v.strip() for v in specific_versions.replace('>=', '').split(',')]
                    batch_items.append(item)
                    normalized_items.append(item)
            except Exception as e:
                logger.error(f"Error normalizing advisory {advisory.get('ghsa_id')}: {e}")
                continue

        if not batch_items:
            continue

        # Submit socket data scraping job for the batch
        job_info = get_socket_data_batch(batch_items, queue_manager)
        if job_info and 'job_id' in job_info:
            all_jobs.append(job_info)

    return {'jobs': all_jobs, 'items': normalized_items}


def process_completed_job_results(job_id: str, status: dict, metadata: dict):
    """Process results from completed batch jobs."""
    try:
        if 'data' not in status:
            logger.warning(f"No data in completed job {job_id}")
            return

        # Process Socket.dev job results
        if metadata and 'package_mapping' in metadata:
            package_mapping = metadata['package_mapping']
            results = []

            for result in status['data']:
                source_url = result.get('metadata', {}).get('sourceURL')
                if not source_url or source_url not in package_mapping:
                    continue

                package_info = package_mapping[source_url]
                package_name = package_info['package_name']
                package_manager = package_info['package_manager']

                # Extract version information from structured data
                structured_data = result.get('json', {})
                suspicious_versions = structured_data.get('suspicious_versions', [])
                unpublished_versions = structured_data.get('unpublished_versions', [])
                all_versions = structured_data.get('versions', [])

                # Combine suspicious and unpublished versions
                if unpublished_versions:
                    suspicious_versions.extend(unpublished_versions)
                    suspicious_versions = list(set(suspicious_versions))

                # Build the final result in the same format as original get_socket_data
                package_result = dict(package_info)  # Copy original package info
                
                # Apply the correct logic: if no suspicious versions, should fetch all versions
                # For now, without the ability to scrape repository structures in batch,
                # we'll implement a fallback that mimics the original behavior
                if suspicious_versions:
                    # Found suspicious versions - in original code this would fetch repository structure
                    # For batch mode, we'll indicate successful detection but note missing repo data
                    socket_data = {
                        "package_name": package_name,
                        "package_manager": package_manager,
                        "suspicious_versions": suspicious_versions,
                        "message": "Repository structure fetching not implemented in batch mode"
                    }
                else:
                    # No suspicious versions found - check if we got ALL versions
                    if all_versions:
                        # We have all versions but none are suspicious
                        # In original code, this would fetch repo structures for all versions
                        socket_data = {
                            "package_name": package_name,
                            "package_manager": package_manager,
                            "all_versions": all_versions,
                            "suspicious_versions": [],
                            "message": "No suspicious versions found, would need to check all versions for repository structures"
                        }
                    else:
                        # Couldn't get version data at all
                        socket_data = {"message": "No suspicious versions found"}

                package_result['socket_data'] = socket_data
                results.append(package_result)

            # Save processed results
            for item in results:
                save_package_result(item)

        logger.info(f"Processed results from job {job_id}")

    except Exception as e:
        logger.error(f"Error processing job {job_id} results: {e}")


def save_package_result(item):
    """Save a single package result to file."""
    try:
        output_file = os.path.join(
            DATA_DIR,
            f"{item.get('package_manager')}",
            f"{item.get('package_name')}.json"
        )
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, 'w+') as out_f:
            json.dump(item, out_f, indent=4)
        logger.info(f"Saved {item.get('package_name')}")
        return True
    except Exception as e:
        logger.error(f"Error saving {item.get('package_name')}: {e}")
        return False


def save_results_parallel(results, max_workers=10):
    """Save results to files in parallel."""
    print(f"💾 Saving {len(results)} results in parallel...")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(save_package_result, item) for item in results]

        for future in tqdm(as_completed(futures), total=len(futures), desc="Saving results"):
            success = future.result()
            if not success:
                # Error already logged in save_package_result
                pass


if __name__ == '__main__':
    # Initialize components
    queue_manager = JobQueueManager()

    # Create monitor thread with callback for processing completed jobs
    monitor = JobMonitor(
        queue_manager=queue_manager,
        firecrawl_app=app,
        poll_interval=5,
        process_callback=process_completed_job_results
    )

    # Create cleanup thread
    cleaner = JobCleaner(
        queue_manager=queue_manager,
        cleanup_interval=3600,  # Clean every hour
        retention_days=7
    )

    try:
        # Start monitoring and cleanup threads
        monitor.start()
        cleaner.start()
        logger.info("Started job monitor and cleaner threads")

        # Load advisories
        with open(ADVISORIES_FILE, 'r') as f:
            advisories = json.load(f)

        print(f"🚀 Processing {len(advisories)} advisories with async batch operations...")

        # Process advisories and submit batch jobs
        process_result = process_advisories_batch(advisories, queue_manager, batch_size=25)
        jobs_submitted = process_result['jobs']
        items_to_process = process_result['items']

        print(f"📋 Submitted {len(jobs_submitted)} batch jobs for {len(items_to_process)} items")
        print(f"⏳ Jobs are being processed asynchronously. Monitor the logs for progress...")

        # Wait for all jobs to complete (with timeout)
        max_wait_time = 1800  # 30 minutes
        check_interval = 10
        elapsed_time = 0

        while elapsed_time < max_wait_time:
            pending_jobs = queue_manager.get_pending_jobs()
            if not pending_jobs:
                print(f"✅ All jobs completed!")
                break

            print(f"⏳ {len(pending_jobs)} jobs still pending...")
            time.sleep(check_interval)
            elapsed_time += check_interval

        if elapsed_time >= max_wait_time:
            print(f"⚠️ Timeout reached. Some jobs may still be pending.")

        # Print summary
        completed_jobs = queue_manager._read_queue(COMPLETED_JOBS_FILE)
        failed_jobs = queue_manager._read_queue(FAILED_JOBS_FILE)

        print(f"\n📊 Final Summary:")
        print(f"  - Completed: {len(completed_jobs)} jobs")
        print(f"  - Failed: {len(failed_jobs)} jobs")
        print(f"  - Still pending: {len(queue_manager.get_pending_jobs())} jobs")

    except KeyboardInterrupt:
        print("\n⚠️ Interrupted by user. Shutting down gracefully...")
    except Exception as e:
        logger.error(f"Error in main process: {e}")
    finally:
        # Stop threads
        monitor.stop()
        cleaner.stop()

        # Wait for threads to finish
        monitor.join(timeout=5)
        cleaner.join(timeout=5)

        print("🏁 Shutdown complete")
