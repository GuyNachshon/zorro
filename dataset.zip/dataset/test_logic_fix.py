#!/usr/bin/env python3
"""
Test script to verify our logic fixes work correctly.
This tests the batch processing logic without making actual API calls.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scraper_2 import process_completed_job_results
import json
from pprint import pprint

def test_batch_processing_logic():
    """Test the updated batch processing logic with mock data."""
    print("🧪 Testing updated batch processing logic...")
    
    # Mock job data that simulates what Firecrawl would return
    mock_job_id = "test_job_123"
    
    # Case 1: Package with suspicious versions found
    mock_status_suspicious = {
        'data': [{
            'metadata': {'sourceURL': 'https://socket.dev/npm/package/paypal-invoicing'},
            'json': {
                'versions': ['1.0.0', '1.0.1', '1.0.2'],
                'unpublished_versions': ['1.0.1'],
                'suspicious_versions': ['1.0.1']
            },
            'html': '<html>mock html</html>'
        }]
    }
    
    mock_metadata_suspicious = {
        'package_mapping': {
            'https://socket.dev/npm/package/paypal-invoicing': {
                'package_name': 'paypal-invoicing',
                'package_manager': 'npm',
                'ghsa_id': 'GHSA-vgmg-gc55-wr7g',
                'summary': 'Malware in paypal-invoicing'
            }
        }
    }
    
    print("\n🔍 Case 1: Package with suspicious versions")
    print("=" * 50)
    process_completed_job_results(mock_job_id, mock_status_suspicious, mock_metadata_suspicious)
    
    # Case 2: Package with NO suspicious versions (should fallback to all versions)
    mock_status_clean = {
        'data': [{
            'metadata': {'sourceURL': 'https://socket.dev/npm/package/some-clean-package'},
            'json': {
                'versions': ['1.0.0', '1.0.1', '1.0.2'],
                'unpublished_versions': [],
                'suspicious_versions': []
            },
            'html': '<html>mock html</html>'
        }]
    }
    
    mock_metadata_clean = {
        'package_mapping': {
            'https://socket.dev/npm/package/some-clean-package': {
                'package_name': 'some-clean-package',
                'package_manager': 'npm',
                'ghsa_id': 'GHSA-test-1234',
                'summary': 'Some vulnerability'
            }
        }
    }
    
    print("\n🔍 Case 2: Package with NO suspicious versions (should show fallback behavior)")
    print("=" * 70)
    process_completed_job_results(mock_job_id, mock_status_clean, mock_metadata_clean)
    
    # Case 3: Package where no version data could be extracted
    mock_status_no_data = {
        'data': [{
            'metadata': {'sourceURL': 'https://socket.dev/npm/package/failed-package'},
            'json': {},  # No version data extracted
            'html': '<html>mock html</html>'
        }]
    }
    
    mock_metadata_no_data = {
        'package_mapping': {
            'https://socket.dev/npm/package/failed-package': {
                'package_name': 'failed-package',
                'package_manager': 'npm',
                'ghsa_id': 'GHSA-fail-5678',
                'summary': 'Failed extraction test'
            }
        }
    }
    
    print("\n🔍 Case 3: Package where version extraction failed")
    print("=" * 50)
    process_completed_job_results(mock_job_id, mock_status_no_data, mock_metadata_no_data)

def check_saved_results():
    """Check what got saved to the package files."""
    print("\n📁 Checking saved results...")
    print("=" * 30)
    
    test_packages = [
        "/Users/guynachshon/Documents/baddon-ai/zorro/dataset/packages/npm/paypal-invoicing.json",
        "/Users/guynachshon/Documents/baddon-ai/zorro/dataset/packages/npm/some-clean-package.json",
        "/Users/guynachshon/Documents/baddon-ai/zorro/dataset/packages/npm/failed-package.json"
    ]
    
    for package_file in test_packages:
        if os.path.exists(package_file):
            print(f"\n📦 {os.path.basename(package_file)}:")
            with open(package_file, 'r') as f:
                data = json.load(f)
                socket_data = data.get('socket_data', {})
                print(f"  Socket data: {socket_data}")
        else:
            print(f"\n❌ {os.path.basename(package_file)}: Not found")

if __name__ == "__main__":
    print("🔬 Testing Logic Fix for Socket.dev Data Extraction")
    print("=" * 60)

    test_batch_processing_logic()
    check_saved_results()

    print("\n" + "=" * 60)
    print("✅ Logic test complete!")