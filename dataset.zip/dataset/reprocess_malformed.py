#!/usr/bin/env python3
"""
Re-process only malformed packages with improved extraction logic.
"""

import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from dotenv import load_dotenv

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
load_dotenv()

# Set the ZenRows API key
os.environ['ZENROWS_API_KEY'] = os.getenv('ZENROWS_API_KEY')

from main import get_socket_data, normalize_item, enrich_item
from scraper_concurrent import save_package_result, sanitize_filename, PackageQueueManager

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MALFORMED_FILE = os.path.join(SCRIPT_DIR, 'malformed_packages.json')
REPROCESSED_LOG = os.path.join(SCRIPT_DIR, 'reprocessed_packages.log')

def should_reprocess(issues):
    """Determine if a package should be reprocessed based on its issues."""
    # Priority order for reprocessing
    priority_issues = [
        'files_without_raw',      # Missing raw links
        'all_dirs_empty',          # Empty directories  
        'some_dirs_empty',         # Some empty directories
        'mixed_link_types',        # Mixed link types
        'suspicious_but_no_structure'  # Has suspicious versions but no structure
    ]
    
    for issue in issues:
        issue_type = issue.split(':')[0]
        if issue_type in priority_issues:
            return True
    
    # Don't reprocess if only issue is a 404/422 error - package likely doesn't exist
    if all('message:' in issue and ('404' in issue or '422' in issue) for issue in issues):
        return False
    
    return False

def reprocess_package(package_info):
    """Re-process a single malformed package."""
    package_name = package_info['package_name']
    package_manager = package_info['package_manager']
    
    try:
        # Get fresh Socket.dev data with improved extraction
        socket_data = get_socket_data(package_manager, package_name)
        
        # Build complete result
        result = {
            'ghsa_id': None,  # We don't have this from malformed data
            'summary': None,
            'package_name': package_name,
            'package_manager': package_manager,
            'socket_data': socket_data,
            'package_url': f"https://www.npmjs.com/package/{package_name}" 
                          if package_manager == 'npm' 
                          else f"https://pypi.org/project/{package_name}"
                          if package_manager == 'pypi'
                          else None,
            'reprocessed': True,
            'original_issues': package_info['issues']
        }
        
        # Save the reprocessed result
        if save_package_result(result):
            return True, None
        else:
            return False, "Failed to save result"
            
    except Exception as e:
        return False, str(e)

def main():
    """Main reprocessing function."""
    print("🔄 Re-processing Malformed Packages")
    print("=" * 60)
    
    # Load malformed packages list
    if not os.path.exists(MALFORMED_FILE):
        print(f"❌ No malformed packages file found at {MALFORMED_FILE}")
        print("Run analyze_malformed.py first to identify malformed packages.")
        return
    
    with open(MALFORMED_FILE, 'r') as f:
        malformed_packages = json.load(f)
    
    print(f"📋 Loaded {len(malformed_packages)} malformed packages")
    
    # Filter packages that should be reprocessed
    to_reprocess = []
    skip_count = 0
    
    for package in malformed_packages:
        if should_reprocess(package['issues']):
            to_reprocess.append(package)
        else:
            skip_count += 1
    
    print(f"📊 Will reprocess {len(to_reprocess)} packages")
    print(f"   Skipping {skip_count} packages (404/422 errors)")
    
    if not to_reprocess:
        print("No packages to reprocess!")
        return
    
    # Ask for confirmation (skip in non-interactive mode)
    print(f"\n⚠️ This will re-process {len(to_reprocess)} packages using ZenRows API")
    import sys
    if sys.stdin.isatty():
        response = input("Continue? (y/n): ")
        if response.lower() != 'y':
            print("Cancelled.")
            return
    else:
        print("Running in non-interactive mode, proceeding automatically...")
    
    # Process in batches to avoid overwhelming the API
    batch_size = 100
    max_workers = 10  # Concurrent workers per batch
    
    successful = 0
    failed = 0
    failed_packages = []
    
    # Open log file for tracking
    with open(REPROCESSED_LOG, 'w') as log_file:
        log_file.write(f"Reprocessing started at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        log_file.write(f"Total packages to reprocess: {len(to_reprocess)}\n\n")
        
        for i in range(0, len(to_reprocess), batch_size):
            batch = to_reprocess[i:i+batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (len(to_reprocess) + batch_size - 1) // batch_size
            
            print(f"\n📦 Processing batch {batch_num}/{total_batches} ({len(batch)} packages)")
            
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(reprocess_package, pkg): pkg 
                    for pkg in batch
                }
                
                with tqdm(total=len(futures), desc=f"Batch {batch_num}") as pbar:
                    for future in as_completed(futures):
                        package = futures[future]
                        
                        try:
                            success, error = future.result(timeout=60)
                            
                            if success:
                                successful += 1
                                log_file.write(f"✅ {package['package_manager']}/{package['package_name']}\n")
                            else:
                                failed += 1
                                failed_packages.append({
                                    'package': f"{package['package_manager']}/{package['package_name']}",
                                    'error': error
                                })
                                log_file.write(f"❌ {package['package_manager']}/{package['package_name']}: {error}\n")
                            
                        except Exception as e:
                            failed += 1
                            failed_packages.append({
                                'package': f"{package['package_manager']}/{package['package_name']}",
                                'error': str(e)
                            })
                            log_file.write(f"❌ {package['package_manager']}/{package['package_name']}: {str(e)}\n")
                        
                        pbar.update(1)
                        pbar.set_postfix({
                            'Success': successful,
                            'Failed': failed
                        })
            
            # Brief pause between batches
            if batch_num < total_batches:
                print("⏸️ Pausing between batches...")
                time.sleep(2)
        
        # Write summary to log
        log_file.write(f"\n\nReprocessing completed at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        log_file.write(f"Successful: {successful}\n")
        log_file.write(f"Failed: {failed}\n")
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 REPROCESSING SUMMARY")
    print("=" * 60)
    print(f"Total attempted: {len(to_reprocess)}")
    print(f"Successfully reprocessed: {successful}")
    print(f"Failed: {failed}")
    print(f"Success rate: {successful / len(to_reprocess) * 100:.1f}%")
    
    if failed_packages:
        print(f"\n⚠️ Failed packages (first 10):")
        for pkg in failed_packages[:10]:
            print(f"  - {pkg['package']}: {pkg['error'][:50]}...")
    
    print(f"\n📄 Full log saved to: {REPROCESSED_LOG}")

if __name__ == "__main__":
    main()