#!/usr/bin/env python3
"""
Concurrent processing system for Socket.dev data extraction using ZenRows.
Replaces Firecrawl batch processing with concurrent individual requests.
"""

import json
import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass, asdict
from typing import Optional, Dict, List, Any
import logging
from tqdm import tqdm
import requests

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('scraper_concurrent')

# File paths for job queues
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
JOBS_DIR = os.path.join(SCRIPT_DIR, 'jobs')
PENDING_JOBS_FILE = os.path.join(JOBS_DIR, 'pending_packages.json')
IN_PROGRESS_JOBS_FILE = os.path.join(JOBS_DIR, 'in_progress_packages.json')
COMPLETED_JOBS_FILE = os.path.join(JOBS_DIR, 'completed_packages.json')
FAILED_JOBS_FILE = os.path.join(JOBS_DIR, 'failed_packages.json')
DATA_DIR = os.path.join(SCRIPT_DIR, 'packages')

# Ensure directories exist
os.makedirs(JOBS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

# Global semaphore for rate limiting ZenRows requests
zenrows_semaphore = threading.Semaphore(20)  # Adjust based on your plan's concurrency
request_delay = 0.1  # Small delay between requests to avoid bursts


class JobStatus(Enum):
    PENDING = 'pending'
    IN_PROGRESS = 'in_progress'
    COMPLETED = 'completed'
    FAILED = 'failed'


@dataclass
class PackageJob:
    """Represents a single package processing job."""
    job_id: str  # Format: "package_manager:package_name"
    package_name: str
    package_manager: str
    ghsa_id: Optional[str] = None
    summary: Optional[str] = None
    status: JobStatus = JobStatus.PENDING
    created_at: str = None
    updated_at: str = None
    completed_at: Optional[str] = None
    error: Optional[str] = None
    retry_count: int = 0
    result: Optional[dict] = None

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at

    def to_dict(self):
        data = asdict(self)
        data['status'] = self.status.value
        return data

    @classmethod
    def from_dict(cls, data):
        data['status'] = JobStatus(data['status'])
        return cls(**data)


class PackageQueueManager:
    """Manages job queues for package processing with persistence."""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._initialize_queues()
    
    def _initialize_queues(self):
        """Initialize queue files if they don't exist."""
        for file_path in [PENDING_JOBS_FILE, IN_PROGRESS_JOBS_FILE, 
                         COMPLETED_JOBS_FILE, FAILED_JOBS_FILE]:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as f:
                    json.dump({}, f)
    
    def _read_queue(self, file_path: str) -> Dict[str, PackageJob]:
        """Read jobs from a queue file."""
        try:
            with self._lock:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    return {k: PackageJob.from_dict(v) for k, v in data.items()}
        except (json.JSONDecodeError, FileNotFoundError):
            return {}
    
    def _write_queue(self, file_path: str, jobs: Dict[str, PackageJob]):
        """Write jobs to a queue file."""
        with self._lock:
            with open(file_path, 'w') as f:
                data = {k: v.to_dict() for k, v in jobs.items()}
                json.dump(data, f, indent=2)
    
    def add_job(self, job: PackageJob):
        """Add a new job to pending queue."""
        pending = self._read_queue(PENDING_JOBS_FILE)
        
        # Check if already processed
        if self.is_completed(job.job_id):
            logger.info(f"Job {job.job_id} already completed, skipping")
            return False
        
        pending[job.job_id] = job
        self._write_queue(PENDING_JOBS_FILE, pending)
        return True
    
    def get_pending_jobs(self) -> Dict[str, PackageJob]:
        """Get all pending jobs."""
        return self._read_queue(PENDING_JOBS_FILE)
    
    def get_in_progress_jobs(self) -> Dict[str, PackageJob]:
        """Get all in-progress jobs."""
        return self._read_queue(IN_PROGRESS_JOBS_FILE)
    
    def get_completed_jobs(self) -> Dict[str, PackageJob]:
        """Get all completed jobs."""
        return self._read_queue(COMPLETED_JOBS_FILE)
    
    def get_failed_jobs(self) -> Dict[str, PackageJob]:
        """Get all failed jobs."""
        return self._read_queue(FAILED_JOBS_FILE)
    
    def is_completed(self, job_id: str) -> bool:
        """Check if a job is already completed."""
        completed = self._read_queue(COMPLETED_JOBS_FILE)
        return job_id in completed
    
    def mark_in_progress(self, job_id: str):
        """Move job from pending to in-progress."""
        pending = self._read_queue(PENDING_JOBS_FILE)
        in_progress = self._read_queue(IN_PROGRESS_JOBS_FILE)
        
        if job_id in pending:
            job = pending.pop(job_id)
            job.status = JobStatus.IN_PROGRESS
            job.updated_at = datetime.now().isoformat()
            in_progress[job_id] = job
            
            self._write_queue(PENDING_JOBS_FILE, pending)
            self._write_queue(IN_PROGRESS_JOBS_FILE, in_progress)
    
    def mark_completed(self, job_id: str, result: dict = None):
        """Move job to completed queue."""
        in_progress = self._read_queue(IN_PROGRESS_JOBS_FILE)
        completed = self._read_queue(COMPLETED_JOBS_FILE)
        
        if job_id in in_progress:
            job = in_progress.pop(job_id)
            job.status = JobStatus.COMPLETED
            job.completed_at = datetime.now().isoformat()
            job.updated_at = job.completed_at
            job.result = result
            completed[job_id] = job
            
            self._write_queue(IN_PROGRESS_JOBS_FILE, in_progress)
            self._write_queue(COMPLETED_JOBS_FILE, completed)
    
    def mark_failed(self, job_id: str, error: str):
        """Move job to failed queue."""
        in_progress = self._read_queue(IN_PROGRESS_JOBS_FILE)
        failed = self._read_queue(FAILED_JOBS_FILE)
        
        if job_id in in_progress:
            job = in_progress.pop(job_id)
            job.status = JobStatus.FAILED
            job.error = error
            job.updated_at = datetime.now().isoformat()
            job.retry_count += 1
            failed[job_id] = job
            
            self._write_queue(IN_PROGRESS_JOBS_FILE, in_progress)
            self._write_queue(FAILED_JOBS_FILE, failed)
    
    def retry_failed_job(self, job_id: str):
        """Move a failed job back to pending for retry."""
        failed = self._read_queue(FAILED_JOBS_FILE)
        pending = self._read_queue(PENDING_JOBS_FILE)
        
        if job_id in failed:
            job = failed.pop(job_id)
            job.status = JobStatus.PENDING
            job.updated_at = datetime.now().isoformat()
            pending[job_id] = job
            
            self._write_queue(FAILED_JOBS_FILE, failed)
            self._write_queue(PENDING_JOBS_FILE, pending)
    
    def get_stats(self) -> dict:
        """Get queue statistics."""
        return {
            'pending': len(self.get_pending_jobs()),
            'in_progress': len(self.get_in_progress_jobs()),
            'completed': len(self.get_completed_jobs()),
            'failed': len(self.get_failed_jobs()),
            'total': sum([
                len(self.get_pending_jobs()),
                len(self.get_in_progress_jobs()),
                len(self.get_completed_jobs()),
                len(self.get_failed_jobs())
            ])
        }
    
    def cleanup_stale_jobs(self, hours=24):
        """Move stale in-progress jobs back to pending."""
        in_progress = self._read_queue(IN_PROGRESS_JOBS_FILE)
        pending = self._read_queue(PENDING_JOBS_FILE)
        stale_time = datetime.now() - timedelta(hours=hours)
        
        stale_jobs = []
        for job_id, job in in_progress.items():
            job_time = datetime.fromisoformat(job.updated_at)
            if job_time < stale_time:
                stale_jobs.append(job_id)
        
        for job_id in stale_jobs:
            job = in_progress.pop(job_id)
            job.status = JobStatus.PENDING
            job.updated_at = datetime.now().isoformat()
            pending[job_id] = job
            logger.info(f"Moved stale job {job_id} back to pending")
        
        if stale_jobs:
            self._write_queue(IN_PROGRESS_JOBS_FILE, in_progress)
            self._write_queue(PENDING_JOBS_FILE, pending)


def process_single_package(job: PackageJob, get_socket_data_func) -> dict:
    """
    Process a single package with rate limiting.
    
    Args:
        job: The package job to process
        get_socket_data_func: Function to get Socket.dev data (from main.py)
    
    Returns:
        Combined result dictionary
    """
    with zenrows_semaphore:
        # Add small delay to avoid request bursts
        time.sleep(request_delay)
        
        try:
            # Get Socket.dev data using the provided function
            socket_data = get_socket_data_func(
                job.package_manager,
                job.package_name
            )
            
            # Combine with advisory data
            result = {
                'ghsa_id': job.ghsa_id,
                'summary': job.summary,
                'package_name': job.package_name,
                'package_manager': job.package_manager,
                'socket_data': socket_data
            }
            
            return result
            
        except requests.HTTPError as e:
            if e.response and e.response.status_code == 429:
                # Rate limited - wait and retry
                logger.warning(f"Rate limited on {job.package_name}, waiting...")
                time.sleep(5)
                return process_single_package(job, get_socket_data_func)  # Retry
            raise
        except Exception as e:
            logger.error(f"Error processing {job.package_name}: {e}")
            raise


def sanitize_filename(name: str) -> str:
    """Sanitize package name for filesystem compatibility."""
    import re
    # Handle @ symbol specially - replace with 'at-' at start, '-' elsewhere
    if name.startswith('@'):
        sanitized = 'at-' + name[1:]
    else:
        sanitized = name
    
    # Replace other problematic characters
    sanitized = sanitized.replace('@', '-').replace('/', '-').replace('\\', '-').replace(' ', '-')
    # Handle any other non-alphanumeric characters (except . _ -)
    sanitized = re.sub(r'[^a-zA-Z0-9._-]', '-', sanitized)
    # Clean up multiple consecutive dashes
    sanitized = re.sub(r'-+', '-', sanitized)
    # Remove leading/trailing dashes
    sanitized = sanitized.strip('-')
    return sanitized


def save_package_result(result: dict):
    """Save package result to JSON file."""
    try:
        package_manager = result.get('package_manager')
        package_name = result.get('package_name')
        
        if not package_manager or not package_name:
            logger.error("Missing package_manager or package_name in result")
            return False
        
        # Create directory for package manager if needed
        output_dir = os.path.join(DATA_DIR, package_manager)
        os.makedirs(output_dir, exist_ok=True)
        
        # Sanitize package name for filesystem compatibility
        safe_filename = sanitize_filename(package_name)
        
        # Save to JSON file
        output_file = os.path.join(output_dir, f"{safe_filename}.json")
        with open(output_file, 'w') as f:
            json.dump(result, f, indent=2)
        
        logger.info(f"Saved {package_name} to {output_file} (as {safe_filename}.json)")
        return True
        
    except Exception as e:
        logger.error(f"Error saving result: {e}")
        return False


def process_advisories_concurrent(advisories: List[dict], 
                                 get_socket_data_func,
                                 normalize_func,
                                 enrich_func,
                                 max_workers: int = 15) -> tuple:
    """
    Process advisories concurrently with job queue tracking.
    
    Args:
        advisories: List of advisory dictionaries
        get_socket_data_func: Function to get Socket.dev data
        normalize_func: Function to normalize advisory data
        enrich_func: Function to enrich advisory data
        max_workers: Maximum concurrent workers
    
    Returns:
        Tuple of (successful_count, failed_count)
    """
    queue_manager = PackageQueueManager()
    
    # Clean up any stale in-progress jobs first
    queue_manager.cleanup_stale_jobs(hours=1)
    
    # Create jobs for all packages
    new_jobs = 0
    for advisory in advisories:
        try:
            item = normalize_func(advisory)
            item = enrich_func(item)
            
            if not item.get('package_name') or not item.get('package_manager'):
                continue
            
            job_id = f"{item['package_manager']}:{item['package_name']}"
            
            # Skip if already completed
            if queue_manager.is_completed(job_id):
                logger.debug(f"Skipping completed: {job_id}")
                continue
            
            # Create and add job
            job = PackageJob(
                job_id=job_id,
                package_name=item['package_name'],
                package_manager=item['package_manager'],
                ghsa_id=item.get('ghsa_id'),
                summary=item.get('summary')
            )
            
            if queue_manager.add_job(job):
                new_jobs += 1
                
        except Exception as e:
            logger.error(f"Error creating job for advisory: {e}")
            continue
    
    logger.info(f"Added {new_jobs} new jobs to queue")
    
    # Get all pending jobs
    pending_jobs = queue_manager.get_pending_jobs()
    
    if not pending_jobs:
        logger.info("No pending jobs to process")
        return 0, 0
    
    successful = 0
    failed = 0
    
    # Process jobs concurrently
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {}
        
        # Submit all pending jobs
        for job_id, job in pending_jobs.items():
            # Mark as in progress
            queue_manager.mark_in_progress(job_id)
            
            # Submit for processing
            future = executor.submit(
                process_single_package,
                job,
                get_socket_data_func
            )
            futures[future] = job
        
        # Process results as they complete
        with tqdm(total=len(futures), desc="Processing packages") as pbar:
            for future in as_completed(futures):
                job = futures[future]
                
                try:
                    result = future.result(timeout=60)
                    
                    # Enrich result with all advisory data
                    result.update({
                        'ghsa_id': job.ghsa_id,
                        'summary': job.summary,
                        'package_url': f"https://www.npmjs.com/package/{job.package_name}"
                        if job.package_manager == 'npm' else None
                    })
                    
                    # Save result
                    if save_package_result(result):
                        queue_manager.mark_completed(job.job_id, result)
                        successful += 1
                    else:
                        queue_manager.mark_failed(job.job_id, "Failed to save result")
                        failed += 1
                    
                except Exception as e:
                    error_msg = str(e)
                    logger.error(f"Failed {job.package_name}: {error_msg}")
                    queue_manager.mark_failed(job.job_id, error_msg)
                    failed += 1
                
                pbar.update(1)
                
                # Print status every 10 packages
                if pbar.n % 10 == 0:
                    stats = queue_manager.get_stats()
                    pbar.set_postfix({
                        'Success': successful,
                        'Failed': failed,
                        'Queue': f"C:{stats['completed']}/F:{stats['failed']}/P:{stats['pending']}"
                    })
    
    return successful, failed


def print_queue_status():
    """Print current queue status in a nice format."""
    queue_manager = PackageQueueManager()
    stats = queue_manager.get_stats()
    
    print(f"""
    ╔═══════════════════════════════╗
    ║      Queue Status             ║
    ╠═══════════════════════════════╣
    ║  Pending:     {stats['pending']:>6}          ║
    ║  In Progress: {stats['in_progress']:>6}          ║
    ║  Completed:   {stats['completed']:>6}          ║
    ║  Failed:      {stats['failed']:>6}          ║
    ║  ─────────────────────────    ║
    ║  Total:       {stats['total']:>6}          ║
    ╚═══════════════════════════════╝
    """)


def retry_failed_packages(max_workers: int = 10):
    """Retry all failed packages."""
    queue_manager = PackageQueueManager()
    failed_jobs = queue_manager.get_failed_jobs()
    
    if not failed_jobs:
        print("No failed jobs to retry")
        return
    
    print(f"Retrying {len(failed_jobs)} failed packages...")
    
    # Move all failed back to pending
    for job_id in failed_jobs:
        queue_manager.retry_failed_job(job_id)
    
    # Now they'll be processed in the next run


if __name__ == "__main__":
    # If run directly, print queue status
    print_queue_status()